$(document).ready(function(){

 Materialize.toast('CHARTS HOME!', 1000, "rounded");
 $('select').material_select();
 	var faculty_list = $('#facultyList');
 	var courseselected,temp,faculty_id;

 	$("#levellist1").hide();


   	 $("#courselist").change(function() {

 			courseselected = $('#courselist :selected').text();
			temp = courseselected.split("_");
			courseid = temp[0];
      
		      $.ajax({
		                type: 'POST',
		                data: {
		                  'courseid': courseid,		                 
		                },
		                url: 'getfaculty.php',
		                beforeSend: function()
		                {
		                
		                },        
		                success: function(phpdata) 
		                {
		                  faculty_list.html(phpdata);
		                  $('select').material_select();
		                   $('#facultySelect').change(function() {
		                      faculty_id = $('#facultySelect :selected').val();
		                      $("#levellist1").show();
		                  });
		                }
		    });

	  });



  $("#viewdetailsbtn").click(function() {

  			courseselected = $('#courselist :selected').text();
			temp = courseselected.split("_");
			courseid = temp[0];
			coursename = temp[1];

  			levelselected = $('#levellist :selected').text();
			temp = levelselected.split("_");
			levelid = temp[1];

			if(courseselected!='Select Course' && levelselected!='Select Level' && faculty_id)
				window.location.href = "index1.helper.php?courseid=" + courseid + "&levelid=" + levelid + "&coursename=" + coursename + "&faculty_id=" + faculty_id;
			else
				Materialize.toast('Select Course, faculty and Level!', 1000, "red rounded");
  });	

  $("#viewdetailsbtn2").click(function() {

  			courseselected = $('#courselist :selected').text();
			temp = courseselected.split("_");
			courseid = temp[0];
			coursename = temp[1];

			if(courseselected!='Select Course'  && faculty_id)
				window.location.href = "index2.helper.php?courseid=" + courseid + "&coursename=" + coursename + "&faculty_id=" + faculty_id;
			else
				Materialize.toast('Select Course and faculty!', 1000, "red rounded");
  });	



});