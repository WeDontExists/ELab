<?php
    session_start();
    
    include_once(__DIR__."/../../../includes/sql.config.php");
    include_once(__DIR__."/../../../includes/general.config.php");
    $sno=0;

    $sql = "SELECT * FROM `users_table` WHERE `ROLE` = 'Z'";
    $db = mysqli_query($link,$sql);
    if(!$db) 
          die("Failed to Insert1:");

    echo "<table class=\"bordered centered highlight\">
                    <thead class=\" indigo white-text\">
                    <tr>
                        <th>SNO</th> 
                        <th>STUDENT ID</th> 
                        <th>NAME</th> 
                        <th>DEPARTMENT</th> 
                    </tr> 
                    </thead><tbody>";
    if(mysqli_num_rows($db) > 0) {
        if(mysqli_query($link,$sql)) {
            while($row = mysqli_fetch_assoc($db)) {
                $sno= $sno + 1;
                echo "<tr>";
                echo "<td>".$sno."</td>";
                echo "<td>".$row['USER_ID']."</td>";
                echo "<td>".$row['FIRST_NAME'].$row['LAST_NAME']."</td>";
                echo "<td>".$row['DEPT']."</td>";
                echo "</tr>";
            }
        }
    }

    echo "</tbody><table>";

?> 