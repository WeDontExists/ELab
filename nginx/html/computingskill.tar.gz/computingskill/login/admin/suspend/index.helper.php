<?php
    session_start();
    if($_SESSION['role'] != 'A') 
    {
    echo "ERROR IN SESSION";
    exit;
    }

    $stat=-1;  
    
    include_once(__DIR__."/../../../includes/sql.config.php");
    include_once(__DIR__."/../../../includes/general.config.php");

    $regno = trim($_REQUEST['regno']);
    $chk = trim($_REQUEST['chk']);

    if($chk==1)
    {

        $sql1= "SELECT ROLE FROM `users_table` WHERE `USER_ID` LIKE '$regno' AND `ROLE` = 'Z'";
        $db1 = mysqli_query($link,$sql1);    

        if(mysqli_num_rows($db1) > 0) {
            $stat = 2;
            echo $stat;
            return;
        }


        $sql = "UPDATE `users_table` SET `ROLE`='Z' WHERE `USER_ID` LIKE '$regno'";
        $db = mysqli_query($link,$sql);
        if(!$db){
            $stat = 1;
            return;
        }
        else
             $stat=0;    

        echo $stat;
    }
    else if($chk==2)
    {

        $sql1= "SELECT ROLE FROM `users_table` WHERE `USER_ID` LIKE '$regno' AND `ROLE` = 'S'";
        $db1 = mysqli_query($link,$sql1);    

        if(mysqli_num_rows($db1) > 0) {
            $stat = 3;
            echo $stat;
            return;
        }

        $sql = "UPDATE `users_table` SET `ROLE`='S' WHERE `USER_ID` LIKE '$regno'";
        $db = mysqli_query($link,$sql);
        if(!$db){
            $stat = 1;
            return;
        }
        else
             $stat=0;    

        echo $stat;
    }
          	
    ?>