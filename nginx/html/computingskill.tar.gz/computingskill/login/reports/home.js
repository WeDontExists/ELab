$(document).ready(function(){
    $('select').material_select();
    
    $(".reportBtn").click(function() {
        window.location = "report.php";
    });
});
