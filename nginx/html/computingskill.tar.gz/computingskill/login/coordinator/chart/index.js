$(document).ready(function(){

 Materialize.toast('CHARTS HOME!', 1000, "rounded");
 $('select').material_select();
 	var facultyselected,temp,faculty_id,levelid,levelselected;



  $("#viewdetailsbtn").click(function() {

  			facultyselected = $('#facultylist :selected').text();
			temp = facultyselected.split("*");
			faculty_id = temp[0];

  			levelselected = $('#levellist :selected').text();
			temp = levelselected.split("_");
			levelid = temp[1];

			if(facultyselected!='Select Faculty' && levelselected!='Select Level')
				window.location.href = "index1.helper.php?levelid=" + levelid + "&faculty_id=" + faculty_id;
			else
				Materialize.toast('Select Faculty and Level!', 1000, "red rounded");
  });	

  $("#viewdetailsbtn2").click(function() {

  			facultyselected = $('#facultylist :selected').text();
			temp = facultyselected.split("*");
			faculty_id = temp[0];

			if(facultyselected!='Select Faculty')
				window.location.href = "index2.helper.php?faculty_id=" + faculty_id;
			else
				Materialize.toast('Select faculty!', 1000, "red rounded");
  });	



});