<?php
    session_start();
    if($_SESSION['role'] != 'C') 
    {
    echo "ERROR IN SESSION";
    exit;
    }

    $final_result = Array();
    $final_result['error'] = 0;
    $uid=0;
  
    
    include_once(__DIR__."/../../../includes/sql.config.php");
    include_once(__DIR__."/../../../includes/general.config.php");

    $regno = trim($_REQUEST['regno']);
    $facultyID=  $_SESSION['uname'];

    
          $sql = "SELECT * FROM `users_table` WHERE USER_ID = '$regno'";
         $db = mysqli_query($link,$sql);

          if(!$db) 
              die("Failed to Insert2: ".mysqli_error($conn));

           $row = null; 
              if(mysqli_num_rows($db) > 0 )
              {
                while ($row = mysqli_fetch_assoc($db))
                {		
                   
                    
                		$final_result['error'] = 1;
                		$final_result['USER_ID']=$row['USER_ID'];
                		$final_result['FIRST_NAME']=$row['FIRST_NAME'];
                		$final_result['LAST_NAME']=$row['LAST_NAME'];
                		$final_result['MAIL_ID']=$row['MAIL_ID'];
                		$final_result['MOBILE']=$row['MOBILE'];
                		$final_result['DEPT']=$row['DEPT'];
                		$final_result['DOB']=$row['DOB'];
                    
          	  }
          	}
            else
               $final_result['error'] = 0;
          	
    	 echo json_encode($final_result);
    ?>