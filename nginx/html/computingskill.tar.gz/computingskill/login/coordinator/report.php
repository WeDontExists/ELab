<?php
    session_start();
    if(!isset($_SESSION['uname']) || $_SESSION['role'] != 'C') {
        echo "ERROR IN SESSION"; 
        exit;
    }
    $username = $_SESSION['uname'];
    $name = $_SESSION['name'];
    $course_name = $_SESSION['course_name'];
    $course_id = $_SESSION['course_id'];
    $TABLE_NAME = "coordinator_".$course_id."";
    
    include_once(__DIR__."/../../includes/sql.config.php");
    include_once(__DIR__."/../../includes/general.config.php");
?>

<html>
<head>
<title>Reports Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../../css/materialize.min.css" type="text/css" /> 
<script src="../../js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="report.js" type="text/javascript"></script>
</head>
<style>
     .container {
           position: relative;
           top: 5%;
        }    
    .srm-text {
            margin-left: 30px;
        }
        
        nav div a img.logo-img {
            height: 100%;
            padding: 4px;
            margin-left: 40px;
        }
        .login {
            padding: 20px;
            text-transform: uppercase;
        }
        .text {
            font-size: 1.2em;
        }
        .title {
            margin: 50px;
            margin-bottom: 10px;
            margin-top: 10px;
            margin-left: 0;
        }
        .btn {
            margin-top: 17px;
        }
        .caps
        {
            text-transform: uppercase;
        }
</style>
<body>
    <nav>
            <div class="nav-wrapper indigo darken-1">
                <a href="<?php echo $HREF_URL  ?>"><img id="image" class="brand-logo logo-img s2" src="../../logo.png"> </img></a>
                </a>
                <a href="#" class="brand-logo  center hide-on-med-and-down"><?php echo $NAVBAR_TEXT; ?></a>
                <ul id="nav-mobile" class="right">
                    <li><a href="../../index.php">Logout</a></li>
                    <li><a href="home.php">Home</a></li>
                </ul>
            </div>
        </nav>

        <div class="container">
            <div class="row">
                <div class="card">
                    <div class="login flow-text indigo darken-1 white-text">
                    View Student Report
                    </div>  
                    <div class="card-content text">
                        <div class="row">
                            <div class="col s8">
                                <div class="input-field col s12">
                                    <select id="facultySelectioID">
                                    <option value="" disabled selected>Select A Faculty</option>
                                    <?php
                                        $sql_regid = "SELECT DISTINCT FACULTY_ID,FACULTY_NAME FROM $TABLE_NAME";
                                        $db_regid = mysqli_query($link,$sql_regid);
                                        if(!$db_regid) 
                                            die("Failed to Insert: ".mysqli_error($link));
                                        if(mysqli_num_rows($db_regid) > 0) {
                                            if(mysqli_query($link,$sql_regid)) {
                                                while($row = mysqli_fetch_assoc($db_regid)){
                                                    $temp1 = $row['FACULTY_ID'];
                                                    $temp2 = $row['FACULTY_NAME'];
                                                    echo "<option value=\"".$temp1."\">".$temp1." - ".$temp2."</option>";
                                                }
                                            }
                                        }
                                    ?>
                                    </select>
                                    <label>Select Faculty</label>
                                </div>
                            </div>
                            <div class="col s4">
                                <a id="addFacultyBtn" class="waves-effect pink waves-light btn">VIEW DETAILS</a>
                            </div>
                        </div>  
                        <div class="row">
                            <div class="col s12"  id="tableDisplay">
                                 STUDENT TABLE WILL COME HERE
                            </div>
                            <div class="right-align col s12">
                                <a id="getReportBtn" class="waves-effect pink waves-light btn">Print Report</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    

    <!-- BASIC SETUP (DO NOT CHANGE) -->
        <script type="text/javascript" src="../../js/materialize.min.js"></script>
        <!-- DONT CHANGE ABOVE IT -->
</body>

  </html>  
