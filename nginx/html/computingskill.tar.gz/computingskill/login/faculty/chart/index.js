$(document).ready(function(){

 Materialize.toast('CHARTS HOME!', 1000);
 $('select').material_select();


  $("#viewdetailsbtn").click(function() {

  			courseselected = $('#courselist :selected').text();
			temp = courseselected.split("_");
			courseid = temp[0];
			coursename = temp[1];

  			levelselected = $('#levellist :selected').text();
			temp = levelselected.split("_");
			levelid = temp[1];

			if(courseselected!='Select Course' && levelselected!='Select Level')
				window.location.href = "index1.helper.php?courseid=" + courseid + "&levelid=" + levelid + "&coursename=" + coursename;
			else
				Materialize.toast('Select Course and Level!', 1000, "red rounded");
  });	

  $("#viewdetailsbtn2").click(function() {

  			courseselected = $('#courselist :selected').text();
			temp = courseselected.split("_");
			courseid = temp[0];
			coursename = temp[1];

			if(courseselected!='Select Course')
				window.location.href = "index2.helper.php?courseid=" + courseid + "&coursename=" + coursename;
			else
				Materialize.toast('Select Course!', 1000, "red rounded");
  });	



});