<?php
    include_once("../../includes/sql.config.php");
    $course_id = mysqli_escape_string($link,$_REQUEST['course_id']);
    $level = mysqli_escape_string($link,$_REQUEST['level']);

    if($level==1) 
    $sql = "SELECT * FROM (SELECT * FROM `top100_table` WHERE `COURSE_ID` =  $course_id ORDER BY LEVEL_1 DESC LIMIT 300 ) AS myList ORDER BY LEVEL_1 DESC";
    else if($level==2) 
    $sql = "SELECT * FROM (SELECT * FROM `top100_table` WHERE `COURSE_ID` =  $course_id ORDER BY LEVEL_2 DESC LIMIT 300 ) AS myList ORDER BY LEVEL_2 DESC";
    else if($level==3) 
    $sql = "SELECT * FROM (SELECT * FROM `top100_table` WHERE `COURSE_ID` =  $course_id ORDER BY LEVEL_3 DESC LIMIT 300 ) AS myList ORDER BY LEVEL_3 DESC";

    $lname="LEVEL_".$level;

    $db = mysqli_query($link,$sql);
    if(!$db) 
          die("Failed to Inser1t: ".mysqli_error($link));
    if(mysqli_num_rows($db) == 0) {
        echo "<h4 class=\"center-align red-text text-darken-3\"> List is empty </h4>";
        return;
    }

    $count = 0;
    echo "<table id=\"table_display_data\" class=\"bordered centered highlight\">
    <thead class=\"indigo white-text\">
    <tr>
    <th>Top No</th>
    <th>Registration Number</th>
    <th>Student Name</th>
    <th>LEVEL_$level</th>
    </tr>
    </thead><tbody>";
    if(mysqli_num_rows($db) > 0) {
        while($row = mysqli_fetch_assoc($db)) {
            $count++;
            echo "<tr>";
            echo "<td>".$count."</td>";
            echo "<td>".$row['REG_ID']."</td>";
            echo "<td>".$row['STD_NAME']."</td>";
            echo "<td>".$row[$lname]."</td>";
            echo "</tr>";
        }
    }
    echo "</tbody><table>";
                            
    

?>
