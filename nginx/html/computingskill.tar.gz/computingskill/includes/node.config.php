<?php

//Change the base url for node
//NOTE: Don't put "/" at the end
$BASE_PATH = "localhost:2200"

?>
